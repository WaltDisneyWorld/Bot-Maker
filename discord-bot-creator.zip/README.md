<div align="center">
  <img 
    src="./resources/icon.png" 
    width="200px" 
    height="200px"
    alt="DBC Logo"
  >
  <h1>
    Discord Bot Creator
  </h1>
  <p>
    A free open-source tool to create Discord Bots.
  </p>
</div>

> Under construction...
